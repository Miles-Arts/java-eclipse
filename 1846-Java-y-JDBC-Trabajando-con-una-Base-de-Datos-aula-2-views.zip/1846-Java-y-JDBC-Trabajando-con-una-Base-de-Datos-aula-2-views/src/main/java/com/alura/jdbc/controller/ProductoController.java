package com.alura.jdbc.controller;

import java.util.ArrayList;
import java.util.List;

public class ProductoController {

	public void modificar(String nombre, String descripcion, Integer id) {
		// TODO
	}

	public void eliminar(Integer id) {
		// TODO
	}

	public List<?> listar() {
		// TODO
		return new ArrayList<>();
	}

    public void guardar(Object producto) {
		// TODO
	}

}
